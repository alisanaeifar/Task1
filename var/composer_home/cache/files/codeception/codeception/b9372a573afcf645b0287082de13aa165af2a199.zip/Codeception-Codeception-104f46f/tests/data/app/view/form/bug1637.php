<!doctype html>
<html>
    <head><title>hi</title></head>
    <body>
        TEST TEST
            <label><input type="radio" name="first_test_radio" value="Yes"/>Yes</label>
            <label><input type="radio" name="first_test_radio" value="No"/>No</label>
            <br/>
    </body>
</html>

<html>
<body>
<form action="/form/button" method="POST">
    <button type="submit" name="btn0">Submit</button>
</form>
<a href="/info"><input type="submit" value="More Info"></a>

<a href="/info"><span><input type="submit" value="Span Info"></span></a>
</body>
</html>
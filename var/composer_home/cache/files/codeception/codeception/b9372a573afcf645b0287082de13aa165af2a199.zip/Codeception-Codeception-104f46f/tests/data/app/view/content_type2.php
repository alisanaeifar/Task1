<html>
<meta charset="windows-1251">
<body>
    <h1>CP1251</h1>
    <p>
        <?= print_r(headers_list()); ?>
    </p>
</body>
</html>

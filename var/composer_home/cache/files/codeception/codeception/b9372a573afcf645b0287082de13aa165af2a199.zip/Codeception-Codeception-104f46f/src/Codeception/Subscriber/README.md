# Event Listeners (Subscribers)

Where this is possible Codeception uses the Observer pattern to separate different parts of framework and make them act independently.

Events are defined in `Codeception\Event`). New features can be added seamlessly when they are created in Subscribers.
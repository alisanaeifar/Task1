<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>issue #3983</title>
</head>
<body>
<form method="get" action="/form/bug3953">
    <select name="select_name" id="select_id">
        <option value="one">first</option>
        <option value="two">second</option>
    </select>
    <input type="text" name="search_name">
    <button>Submit</button>
</form>
</body>
</html>

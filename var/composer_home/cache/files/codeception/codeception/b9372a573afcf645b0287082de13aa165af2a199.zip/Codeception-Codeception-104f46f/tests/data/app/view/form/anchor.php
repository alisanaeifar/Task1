<html>
<title>TestEd Beta 2.0</title>
<body>

<h1>Welcome to test app!</h1>

<form action="#a" method="post">
    <input name="field1" />
    <input type="submit" value="Hash Form" />
    <button type="submit" title="Hash Button Form"></button>
</form>

<a href="#b">Hash Link</a>

<a href="#c">
    <input type="submit" value="Hash Button" />
</a>


</body>
</html>

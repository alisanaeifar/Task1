<?php
namespace Consolidation\OutputFormatters\StructuredData;

/**
 * Old name for PropertyList class.
 *
 * @deprecated
 */
class AssociativeList extends PropertyList
{

}

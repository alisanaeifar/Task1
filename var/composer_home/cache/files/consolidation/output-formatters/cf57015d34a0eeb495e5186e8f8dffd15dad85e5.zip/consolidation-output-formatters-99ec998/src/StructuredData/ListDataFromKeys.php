<?php
namespace Consolidation\OutputFormatters\StructuredData;

/**
 * @deprecated Use UnstructuredListData
 */
class ListDataFromKeys extends AbstractListData
{
}

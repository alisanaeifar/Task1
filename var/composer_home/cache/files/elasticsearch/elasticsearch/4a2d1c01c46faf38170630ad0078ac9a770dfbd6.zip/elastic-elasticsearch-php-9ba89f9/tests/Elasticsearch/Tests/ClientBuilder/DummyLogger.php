<?php
declare(strict_types = 1);

namespace Elasticsearch\Tests\ClientBuilder;

class DummyLogger
{

}

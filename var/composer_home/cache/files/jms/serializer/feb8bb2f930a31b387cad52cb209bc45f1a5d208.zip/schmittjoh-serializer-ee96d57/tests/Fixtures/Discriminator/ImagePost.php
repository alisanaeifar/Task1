<?php

namespace JMS\Serializer\Tests\Fixtures\Discriminator;

class ImagePost extends Post
{
}

<?php

namespace JMS\Serializer\Tests\Fixtures\Discriminator;

class Moped extends Vehicle implements VehicleInterface
{
}

<?php

namespace JMS\Serializer\Tests\Fixtures\Discriminator;

class ObjectWithXmlAttributeDiscriminatorChild extends ObjectWithXmlAttributeDiscriminatorParent
{
}
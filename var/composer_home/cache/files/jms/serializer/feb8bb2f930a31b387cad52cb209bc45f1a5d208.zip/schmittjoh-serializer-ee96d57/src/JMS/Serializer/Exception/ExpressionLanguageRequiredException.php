<?php

namespace JMS\Serializer\Exception;

/**
 * @author Asmir Mustafic <goetas@gmail.com>
 */
class ExpressionLanguageRequiredException extends LogicException
{
}

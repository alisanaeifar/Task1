<?php

namespace JMS\Serializer\Tests\Fixtures\DiscriminatorGroup;

class Car extends Vehicle
{
}

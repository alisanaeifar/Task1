<?php

namespace JMS\Serializer\Tests\Fixtures\Discriminator;

class ObjectWithXmlNotCDataDiscriminatorChild extends ObjectWithXmlNotCDataDiscriminatorParent
{
}

<?php

namespace JMS\Serializer\Tests\Fixtures\Discriminator;

class ObjectWithXmlNamespaceAttributeDiscriminatorChild extends ObjectWithXmlNamespaceAttributeDiscriminatorParent
{
}

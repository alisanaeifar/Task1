<?php

namespace JMS\Serializer\Annotation;

/**
 * @Annotation
 * @Target("METHOD")
 */
final class PostSerialize
{
}

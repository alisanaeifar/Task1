<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\Prototype;

interface FooInterface
{
}

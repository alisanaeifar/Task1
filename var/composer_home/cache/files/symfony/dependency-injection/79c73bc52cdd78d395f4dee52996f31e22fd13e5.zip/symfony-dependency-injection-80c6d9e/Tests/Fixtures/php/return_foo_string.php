<?php
    return 'foo';

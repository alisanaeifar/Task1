<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\Container;

class ConstructorWithMandatoryArgumentsContainer
{
    public function __construct($mandatoryArgument)
    {
    }
}

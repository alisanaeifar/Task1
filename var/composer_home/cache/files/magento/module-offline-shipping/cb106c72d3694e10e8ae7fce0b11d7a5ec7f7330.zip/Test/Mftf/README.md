# Offline Shipping Functional Tests

The Functional Test Module for **Magento Offline Shipping** module.

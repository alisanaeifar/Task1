# EavGraphQl

**EavGraphQl** primarily provides the GraphQl module information to generate metadata for Eav attributes.

This component is designed to provide Message Queue Framework 

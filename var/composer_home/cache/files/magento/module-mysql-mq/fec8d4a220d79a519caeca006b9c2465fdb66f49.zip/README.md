# MysqlMq

**MysqlMq** provides message queue implementation based on MySQL.

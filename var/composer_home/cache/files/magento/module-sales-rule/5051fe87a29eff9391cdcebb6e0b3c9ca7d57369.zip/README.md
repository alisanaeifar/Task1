SalesRule module is responsible for managing and processing Promotion Shopping Cart Rules.


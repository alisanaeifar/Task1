# Sitemap Functional Tests

The Functional Test Module for **Magento Sitemap** module.

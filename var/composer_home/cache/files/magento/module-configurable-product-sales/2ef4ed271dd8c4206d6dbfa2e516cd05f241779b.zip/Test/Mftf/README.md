# Configurable Product Sales Functional Tests

The Functional Test Module for **Magento Configurable Product Sales** module.

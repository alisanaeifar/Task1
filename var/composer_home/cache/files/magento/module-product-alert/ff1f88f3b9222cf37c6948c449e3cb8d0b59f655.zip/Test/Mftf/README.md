# Product Alert Functional Tests

The Functional Test Module for **Magento Product Alert** module.

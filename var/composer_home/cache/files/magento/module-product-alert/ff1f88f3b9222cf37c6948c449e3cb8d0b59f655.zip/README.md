The Magento_ProductAlert module enables product alerts, which allow customers to sign up for emails about product price or stock status change.

# Tax Graph Ql Functional Tests

The Functional Test Module for **Magento Tax Graph Ql** module.

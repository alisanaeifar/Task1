# User

**User** enables admin users to manage and assign roles to administrators and other non-customer users,
reset user passwords, and invalidate access tokens.
Different roles can be assigned to different users to define their permissions.
For admin passwords, it enables setting lifetimes and locking them when expired or when a specified numbers of failures have occurred. It allows preventing password brute force attacks for system backend.

# Checkout Functional Tests

The Functional Test Module for **Magento Checkout** module.

<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Paypal\Test\Unit\Model;

use \Magento\Paypal\Model\AbstractConfig;

/**
 * Class AbstractConfigTesting
 * @package Magento\Paypal\Test\Unit\Model
 */
class AbstractConfigTesting extends AbstractConfig
{

}

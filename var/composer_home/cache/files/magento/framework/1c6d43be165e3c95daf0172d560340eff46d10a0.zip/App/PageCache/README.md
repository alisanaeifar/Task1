Provides a "pre-wiring" for implementation of full page caching feature.

The Magento application framework runs this as an indirection layer, while another component is expected to plugin into it with its own full page cache implementation.

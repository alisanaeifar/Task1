# Catalog Analytics Functional Tests

The Functional Test Module for **Magento Catalog Analytics** module.

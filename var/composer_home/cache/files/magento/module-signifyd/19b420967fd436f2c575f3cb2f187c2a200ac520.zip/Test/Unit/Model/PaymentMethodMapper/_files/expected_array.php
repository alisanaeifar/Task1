<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
return [
    'payment_method_1' => 'PAYMENT_CARD',
    'payment_method_2' => 'PAYPAL_ACCOUNT',
    'payment_method_3' => 'CHECK',
    'payment_method_4' => 'CASH',
    'payment_method_5' => 'FREE'
];

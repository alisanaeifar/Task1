# Customer Analytics Functional Tests

The Functional Test Module for **Magento Customer Analytics** module.

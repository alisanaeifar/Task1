# Url Rewrite Graph Ql Functional Tests

The Functional Test Module for **Magento Url Rewrite Graph Ql** module.

# Downloadable Graph Ql Functional Tests

The Functional Test Module for **Magento Downloadable Graph Ql** module.

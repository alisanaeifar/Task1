# Page Cache Functional Tests

The Functional Test Module for **Magento Page Cache** module.

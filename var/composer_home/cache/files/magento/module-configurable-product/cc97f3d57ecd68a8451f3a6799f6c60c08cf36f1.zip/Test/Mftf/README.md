# Configurable Product Functional Tests

The Functional Test Module for **Magento Configurable Product** module.

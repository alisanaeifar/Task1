<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

return [
    'sku' => 'product-sku',
    '_custom_option_row_title' => 'test row title',
    '_custom_option_row_price' => 'incorrect_price',
    '_custom_option_row_sku' => 'option-value-sku',
    '_custom_option_row_sort' => 0
];

# Customer Functional Tests

The Functional Test Module for **Magento Customer** module.

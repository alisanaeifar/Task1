The Magento_Customer module serves to handle the customer data (Customer, Customer Address and Customer Group entities) both in the admin panel and the storefront. 
For customer passwords, the module implements upgrading hashes. 

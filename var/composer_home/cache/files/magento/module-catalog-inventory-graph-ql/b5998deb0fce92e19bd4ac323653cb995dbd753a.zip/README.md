# CatalogInventoryGraphQl

**CatalogInventoryGraphQl** provides type information for the GraphQl module
to generate inventory stock fields for product information endpoints.

# Grouped Product Functional Tests

The Functional Test Module for **Magento Grouped Product** module.

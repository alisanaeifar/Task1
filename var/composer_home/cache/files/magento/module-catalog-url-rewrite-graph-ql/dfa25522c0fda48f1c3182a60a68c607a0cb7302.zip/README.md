# CatalogUrlRewriteGraphQl

**CatalogUrlRewriteGraphQl** provides type information for the GraphQl module
to generate url rewrite fields for catalog and product information endpoints.

# GroupedProductGraphQl

**GroupedProductGraphQl** provides type and resolver information for the GraphQl module
to generate grouped product information.

# Overview
## Purpose of module

Magento\SalesSequence module is responsible for sequences processing in Sales module,
Magento\SalesSequence module manages sequences for next system entities and flows:
* order;
* invoice;
* shipment;
* credit memos;
Magento\SalesSequence module is required for Magento\Sales module.

# Deployment
## System requirements

The Magento_SalesSequence module does not have any specific system requirements.

## Install
The Magento_SalesSequence module is installed automatically (using the native Magento install mechanism) without any additional actions.

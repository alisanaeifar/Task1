# Sales Sequence Functional Tests

The Functional Test Module for **Magento Sales Sequence** module.

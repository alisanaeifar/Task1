# Overview
## Purpose of module

The Magento\Ui module introduces a set of common UI components, which could be used and configured via layout XML files.

# Deployment
## System requirements

The Magento\Ui module does not have any specific system requirements.

## Install
The Magento\Ui module is installed automatically (using the native Magento Setup). No additional actions required.

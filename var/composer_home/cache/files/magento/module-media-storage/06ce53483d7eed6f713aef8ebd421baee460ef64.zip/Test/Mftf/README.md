# Media Storage Functional Tests

The Functional Test Module for **Magento Media Storage** module.

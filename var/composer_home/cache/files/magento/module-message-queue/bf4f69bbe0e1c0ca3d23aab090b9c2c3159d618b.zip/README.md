# MessageQueue

**MessageQueue** provides support of Advanced Message Queuing Protocol

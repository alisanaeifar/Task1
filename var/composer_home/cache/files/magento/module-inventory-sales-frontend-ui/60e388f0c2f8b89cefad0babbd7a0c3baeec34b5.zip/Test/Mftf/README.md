# Inventory Sales Frontend Ui Functional Tests

The Functional Test Module for **Magento Inventory Sales Frontend Ui** module.

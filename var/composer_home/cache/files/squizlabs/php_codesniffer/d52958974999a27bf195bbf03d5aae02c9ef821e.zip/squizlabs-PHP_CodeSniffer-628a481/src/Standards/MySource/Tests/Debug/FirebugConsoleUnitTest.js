console.info();
console.warn();
console.test();
con.sole();
var console = {
    console: 'string';
};
function console() {}
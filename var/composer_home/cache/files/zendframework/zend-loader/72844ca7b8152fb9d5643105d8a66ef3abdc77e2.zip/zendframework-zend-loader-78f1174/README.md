# zend-loader

[![Build Status](https://secure.travis-ci.org/zendframework/zend-loader.svg?branch=master)](https://secure.travis-ci.org/zendframework/zend-loader)
[![Coverage Status](https://coveralls.io/repos/github/zendframework/zend-loader/badge.svg?branch=master)](https://coveralls.io/github/zendframework/zend-loader?branch=master)

zend-loader provides different strategies for autoloading PHP classes.

- File issues at https://github.com/zendframework/zend-loader/issues
- Documentation is at https://docs.zendframework.com/zend-loader/

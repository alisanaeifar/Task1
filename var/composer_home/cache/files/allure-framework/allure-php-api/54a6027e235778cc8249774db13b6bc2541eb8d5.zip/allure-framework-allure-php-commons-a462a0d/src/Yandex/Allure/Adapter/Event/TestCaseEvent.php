<?php

namespace Yandex\Allure\Adapter\Event;

interface TestCaseEvent extends Event
{
}

<?php

namespace Yandex\Allure\Adapter;

class AllureException extends \Exception
{
}

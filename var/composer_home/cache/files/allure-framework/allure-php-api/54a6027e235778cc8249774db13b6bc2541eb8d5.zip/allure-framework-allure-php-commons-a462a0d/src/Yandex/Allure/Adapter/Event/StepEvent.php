<?php

namespace Yandex\Allure\Adapter\Event;

interface StepEvent extends Event
{
}

<?php

namespace Pelago\Tests\Unit\Emogrifier\HtmlProcessor\Fixtures;

use Pelago\Emogrifier\HtmlProcessor\AbstractHtmlProcessor;

/**
 * Fixture class for AbstractHtmlProcessor.
 *
 * @author Oliver Klee <github@oliverklee.de>
 */
class TestingHtmlProcessor extends AbstractHtmlProcessor
{
}
